import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, FileText, Plus, Save, FolderOpen, Settings } from 'lucide-react';
import { toast } from 'sonner';

/**
 * Minimalist Productivity Design
 * - Clean, distraction-free interface inspired by Windows Notepad
 * - Off-white background with deep charcoal text
 * - Monospace font for code/text editing
 * - Keyboard-first navigation with minimal UI chrome
 * - Status bar showing file information
 */

interface FileData {
  name: string;
  content: string;
  lastModified: Date;
}

export default function Home() {
  const [content, setContent] = useState('');
  const [fileName, setFileName] = useState('untitled.txt');
  const [isModified, setIsModified] = useState(false);
  const [lineCount, setLineCount] = useState(1);
  const [charCount, setCharCount] = useState(0);
  const [cursorPosition, setCursorPosition] = useState({ line: 1, column: 1 });
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  // Update line and character count
  useEffect(() => {
    const lines = content.split('\n').length;
    setLineCount(lines);
    setCharCount(content.length);
  }, [content]);

  // Handle text input
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setIsModified(true);
    updateCursorPosition();
  };

  // Update cursor position
  const updateCursorPosition = () => {
    if (textAreaRef.current) {
      const text = textAreaRef.current.value;
      const selectionStart = textAreaRef.current.selectionStart;
      const textBeforeCursor = text.substring(0, selectionStart);
      const lines = textBeforeCursor.split('\n');
      const currentLine = lines.length;
      const currentColumn = lines[lines.length - 1].length + 1;
      setCursorPosition({ line: currentLine, column: currentColumn });
    }
  };

  // Create new file
  const handleNewFile = () => {
    if (isModified) {
      const confirmed = window.confirm('You have unsaved changes. Create a new file anyway?');
      if (!confirmed) return;
    }
    setContent('');
    setFileName('untitled.txt');
    setIsModified(false);
    toast.success('New file created');
  };

  // Open file
  const handleOpenFile = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.text';
    input.onchange = (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const text = event.target?.result as string;
          setContent(text);
          setFileName(file.name);
          setIsModified(false);
          toast.success(`Opened: ${file.name}`);
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  // Save file
  const handleSaveFile = () => {
    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = fileName;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    setIsModified(false);
    toast.success(`Saved: ${fileName}`);
  };

  // Save as new file
  const handleSaveAs = () => {
    const newName = window.prompt('Enter file name:', fileName);
    if (newName) {
      setFileName(newName.endsWith('.txt') ? newName : `${newName}.txt`);
      handleSaveFile();
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 'n':
            e.preventDefault();
            handleNewFile();
            break;
          case 'o':
            e.preventDefault();
            handleOpenFile();
            break;
          case 's':
            e.preventDefault();
            if (e.shiftKey) {
              handleSaveAs();
            } else {
              handleSaveFile();
            }
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [content, fileName, isModified]);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Menu Bar */}
      <div className="border-b border-border bg-secondary px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <span className="text-sm font-medium">
            {isModified ? `*${fileName}` : fileName}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={handleNewFile}
            title="New (Ctrl+N)"
            className="h-8 px-2"
          >
            <Plus className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleOpenFile}
            title="Open (Ctrl+O)"
            className="h-8 px-2"
          >
            <FolderOpen className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleSaveFile}
            title="Save (Ctrl+S)"
            className="h-8 px-2"
          >
            <Save className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleSaveAs}
            title="Save As (Ctrl+Shift+S)"
            className="h-8 px-2"
          >
            <Menu className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 overflow-hidden flex flex-col">
        <textarea
          ref={textAreaRef}
          value={content}
          onChange={handleTextChange}
          onKeyUp={updateCursorPosition}
          onClick={updateCursorPosition}
          className="editor-content flex-1 w-full p-4 resize-none focus:outline-none bg-background text-foreground border-none"
          placeholder="Start typing... (Ctrl+N: New, Ctrl+O: Open, Ctrl+S: Save)"
          spellCheck="false"
        />
      </div>

      {/* Status Bar */}
      <div className="border-t border-border bg-secondary px-4 py-2 flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span>Line {cursorPosition.line}, Column {cursorPosition.column}</span>
          <span>•</span>
          <span>{lineCount} lines</span>
          <span>•</span>
          <span>{charCount} characters</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-primary font-medium">UTF-8</span>
          <span>•</span>
          <span>Windows (CRLF)</span>
        </div>
      </div>
    </div>
  );
}
